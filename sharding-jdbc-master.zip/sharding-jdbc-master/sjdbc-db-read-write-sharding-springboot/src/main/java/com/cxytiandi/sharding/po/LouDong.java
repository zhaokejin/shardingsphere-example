package com.cxytiandi.sharding.po;

/**
 * 不分表
 * @author yinjihuan
 *
 */
public class LouDong {

	private String id;
	
	private String city;
	
	private String region;
	
	private String name;
	
	private String ldNum;
	
	private String unitNum;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLdNum() {
		return ldNum;
	}

	public void setLdNum(String ldNum) {
		this.ldNum = ldNum;
	}

	public String getUnitNum() {
		return unitNum;
	}

	public void setUnitNum(String unitNum) {
		this.unitNum = unitNum;
	}
	
}
